Add your profile photo as assets/profile.jpg and your CV as assets/cv.pdf.
The profile avatar shows H until your photo is added.
